import json
import re
from pathlib import Path

from ..ingredients_package.ingredients import match_available_ingredients
from .RecipeClass import Recipe


ENTRIES = Path(".")


def search_recipe(available_ingredients=None, name=None):
    """Fetches a json file and iterates through its items and retrieves
    the recipe that satisfies either being the same name or having
    the same ingredients/ containing some of the ingredients from the available
    ingredients


    Args:
        available_ingredients {list}: list of strings from user input which
        indicates the available ingredients he wants to cook with
        name {string}: indicates the name of the recipe the user wants to search

    Returns:
        {list}: list of all recipes from the json file that has the ingredients
        in available_ingredients or is the same name with argument name

    Raises:
        ValueError: No file found
        ValueError: empty file
    """
    try:
        # Looks for a file from the current directory and its child directories
        # with the file name of "recipes.json"
        path_to_json = [
            str(i)
            for i in ENTRIES.glob("**/*")
            if str(i).endswith("recipes.json")
        ][0]

        if not path_to_json:
            raise ValueError("No file found with recipe.json in title")

        available_recipe = []

        with open(f"{path_to_json}", "r") as recipe:
            recipe_list = json.load(recipe)

            if not recipe_list:
                raise ValueError("No recipes found in file")

            # Gets the ingredients for each of the recipes in the database
            recipe_ingredient_list = [
                i["ingredients"] for i in recipe_list
            ]  # with quantity and type
            available_recipe = (
                match_available_ingredients(
                    recipe_ingredient_list, available_ingredients, recipe_list
                )
                if available_ingredients
                else search_by_name(name, recipe_list)
            )

        return available_recipe
    except ValueError as e:
        print(str(e))


def search_by_name(name, recipes):
    """ """
    pattern = f"{name.lower()}"
    search_list = [
        recipe
        for recipe in recipes
        if re.search(pattern, recipe["name"].lower())
    ]
    return search_list


def set_rating(recipe_list):
    """
    """
    for index, recipe in enumerate(recipe_list, start=1):
        print(f"{index} {recipe.name}")
    while True:
        print()
        user_input = input("Select recipe you would like to rate: ")

        if not user_input.isnumeric():
            print("Please enter the number corresponding to the recipe")
            continue
        else:
            break
    print()
    recipe_index = int(user_input) - 1
    if recipe_index > len(recipe_list):
        raise ValueError("Index not in range")
    # print(f"What would you like to rate {recipe_list[recipe_index].name}?")

    rating = int(input("Rating: "))
    if rating < 0 or rating > 100:
        raise ValueError("Please enter value between 0 - 100")
    # print(recipe_list[recipe_index].get_rating())

    recipe_list[recipe_index].add_rating(rating)

    print(recipe_list[recipe_index].get_rating())
    path_to_json = [
        str(i) for i in ENTRIES.glob("**/*") if str(i).endswith("recipes.json")
    ][0]
    if not path_to_json:
        raise ValueError("No file found with recipe.json in title")
    with open(f"{path_to_json}", "w") as f:
        # make list of objects using Recipe class
        to_json = [recipe.__dict__ for recipe in recipe_list]
        json.dump(to_json, f)

    return True


def rate_recipe():
    while True:
        try:
            # Looks for a file from the current directory and its child directories
            # with the file name of "recipes.json"
            path_to_json = [
                str(i)
                for i in ENTRIES.glob("**/*")
                if str(i).endswith("recipes.json")
            ][0]

            if not path_to_json:
                raise ValueError("No file found with recipe.json in title")

            with open(f"{path_to_json}", "r") as recipe:
                json_list = json.load(recipe)
                # creates a list of Recipe class using json list as base
                recipe_list = [Recipe(**recipe) for recipe in json_list]
                print()
                if set_rating(recipe_list):
                    break

        except ValueError as e:
            print(str(e))
    pass
