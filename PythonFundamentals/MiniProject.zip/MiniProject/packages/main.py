import re
import sys
from pathlib import Path

from .recipe_package.recipe import search_recipe


def search_with_ingredients():
    """Starter boilerplate for searching recipes with ingredients.
    Also takes in user input to parse ingredient list

    Returns:
        A list with a type of the Recipe class.
        example:
            {"name":"name",
            "ingredients: {"quantity":[int],}
                           "name":[string],
                           "type":[string]},
            "steps":[list: string],
            "rating":[list: int]
            }
    """

    # Todo: make into while loop and exit when user types "done"
    print()
    ingredients_input = input("Enter the ingredients you have: ")
    ingredients_list = []
    ingredients_list.extend(get_ingredient_list(ingredients_input))

    return search_recipe(ingredients_list)


def get_ingredient_list(input):
    """Helper function to get ingredients from a string using regex.
    replaces any non-alphanumeric character with addition to space and replaces
    with "|" for easier split

    Returns:
        A list of ingredients which will be used to find recipes with the same
        ingredients
    """
    match = re.sub(r"([^a-zA-Z\d\s] ?)", "|", input)
    ingredients_list = match.split("|")

    return ingredients_list


def search_with_recipe():
    """ Starter boilerplate for searching recipes using name of the dish.

    Returns:
        A list with a type of the Recipe class.
        example:
            {"name":"name",
            "ingredients: {"quantity":[int],}
                           "name":[string],
                           "type":[string]},
            "steps":[list: string],
            "rating":[list: int]
            }
    """
    print()
    name_input = input("Enter the recipe you want to look for: ").strip()

    return search_recipe(name=name_input)
